const API_KEY = "AIzaSyCXX8EcGZlkbxPh-Me1rrMZfwi4gB1F3DQ";
const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=" + API_KEY;

chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.insertCSS({
    target: { tabId: tab.id },
    files: ['styles.css']
  });
  // Luego inyecta el script de contenido
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
});

// Escucha mensajes desde content.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "analyzeContent") {
    // Cuando recibe el contenido, llama a la API de Gemini
    callGeminiAPI(request.data, sender.tab.id);
  }
});

async function callGeminiAPI(pageContent, tabId) {
  try {
    const prompt = `Analiza el siguiente texto extraído de una página web y determina si es apropiado para un público general (todas las edades). Considera temas como violencia, lenguaje explícito, contenido para adultos, o temas sensibles. Responde únicamente con una de estas dos palabras: "SEGURO" si es apropiado, o "ADVERTENCIA" si no lo es.\n\nContenido: "${pageContent.title}. ${pageContent.description}. ${pageContent.textSample}"`;

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }]
      })
    });

    if (!response.ok) {
        throw new Error(`Error en la API: ${response.statusText}`);
    }

    const data = await response.json();
    const result = data.candidates[0].content.parts[0].text.trim().toUpperCase();

    // Envía el resultado de vuelta a content.js para mostrar la advertencia
    chrome.tabs.sendMessage(tabId, {
      action: "showWarning",
      result: result
    });

  } catch (error) {
    console.error("Error al llamar a la API de Gemini:", error);
    // Informar al usuario del error
     chrome.tabs.sendMessage(tabId, {
      action: "showWarning",
      result: "ERROR"
    });
  }
}