// Función para extraer metadatos y texto del cuerpo
function getPageContent() {
  const title = document.title || '';
  const description = document.querySelector('meta[name="description"]')?.content || '';
  // Tomamos una muestra del texto para no sobrecargar la API
  const textSample = document.body.innerText.substring(0, 3000);

  // Envía los datos al background script para análisis
  chrome.runtime.sendMessage({
    action: "analyzeContent",
    data: {
      title,
      description,
      textSample
    }
  });
}

// Función para mostrar la advertencia visual en la página
function displayWarning(result) {
  // Elimina cualquier advertencia anterior
  const oldWarning = document.getElementById('gemini-content-warning');
  if (oldWarning) {
    oldWarning.remove();
  }

  const warningDiv = document.createElement('div');
  warningDiv.id = 'gemini-content-warning';

  let message = '';
  
  switch (result) {
    case 'SEGURO':
      message = '✅ Contenido seguro para todo público.';
      warningDiv.className = 'seguro';
      break;
    case 'ADVERTENCIA':
      message = '⚠️ ¡Atención! Este contenido puede no ser apropiado para todo público.';
      warningDiv.className = 'advertencia';
      break;
    default:
       message = '❌ Error al analizar el contenido.';
       warningDiv.className = 'error';
  }
  
  warningDiv.textContent = message;
  document.body.appendChild(warningDiv);

  // La advertencia desaparece después de 8 segundos
  setTimeout(() => {
    warningDiv.style.opacity = '0';
    setTimeout(() => warningDiv.remove(), 500);
  }, 8000);
}

// Inicia el análisis
getPageContent();

// Escucha la respuesta del background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "showWarning") {
    displayWarning(request.result);
  }
});